# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 17:13:03 2022

@author: tfv01
"""

#%%
import cv2
import matplotlib.pyplot as plt
import numpy as np
import math

#%%
img = cv2.imread('FOTOS BOAS3 - TAGAZUL/P_ADIANTADAA.JPG', cv2.IMREAD_GRAYSCALE)
img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
x1 = 0 #0
y1 = 650 #883
x2 = 2000 #2000
y2 = 1033 #1165

valorTesoura = 241

img = img[y1:y2, x1:x2]
out = img.copy()


#%%
#################### testando opening ######################
# binarize the image
binr = cv2.threshold(out, 0, 255,
                     cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
 
# define the kernel
kernel = np.ones((3, 3), np.uint8)
 
# opening the image
opening = cv2.morphologyEx(binr, cv2.MORPH_OPEN,
                           kernel, iterations=1)
# print the output
plt.imshow(opening, cmap='gray')

############################################################

#%%
canny = cv2.Canny(opening, 25, 60, None, 3)

lines = cv2.HoughLines(canny, 1, np.pi / 180,300, None, 0, 0) #200 PARA TODAS MENOS P_ADIANTADA OU 180

print(len(lines))


posicoes_y = []
if lines is not None:
    
    # lines = np.sort(lines, axis=0)

    for i in range(0, len(lines)):
    
        rho = lines[i][0][0]
        theta = lines[i][0][1]
    
        if theta > 0.5: # Eliminar retas na vertical
            #print(theta)

            a = math.cos(theta)
            b = math.sin(theta)

            x0 = a * rho
            y0 = b * rho

            pt1 = (int(x0 + 1000*(-b)), int(y0 + 1000*(a)))
            pt2 = (int(x0 - 1000*(-b)), int(y0 - 1000*(a)))

            posicoes_y.append(pt1[1])
            #posicoes_y.append(pt2[1])

            cv2.line(out, pt1, pt2, (0,0,255), 3, cv2.LINE_AA)
            #cv2.line(out, (0,valorTesoura), (2000,valorTesoura), (255, 255, 255), 3, cv2.LINE_AA)
            
            y = int(lines[i,0,0])          

            cv2.putText(out, 'y = ' + str(y), (1000, y+10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (127), 1, cv2.LINE_AA)


#%% Plot results
plt.figure(figsize=(64,64))
plt.subplot(3,1,1), plt.imshow(img, cmap='gray')
plt.subplot(3,1,2), plt.imshow(canny, cmap='gray')
plt.subplot(3,1,3), plt.imshow(out, cmap='gray')

def situacao(ValorTesoura, PosicoesY):
    count_atrasadas = 0
    count_adiantadas = 0
    for i in range(0, len(PosicoesY)):
        if(PosicoesY[i] < ValorTesoura):
            count_atrasadas = count_atrasadas + 1
        elif(PosicoesY[i] > ValorTesoura):
            count_adiantadas = count_adiantadas + 1

    result = []
    result.append(count_atrasadas)
    result.append(count_adiantadas)

    return result    
    
def pega_linha_mais_proxima(ValorTesoura, PosicoesY, status):
    menor = 9999
    maior = -1
    # if(status == 1):
    #     for i in range(0, len(PosicoesY)):
    #         if(PosicoesY[i] < ValorTesoura and PosicoesY[i] < menor):
    #             menor = PosicoesY[i]
    #     return menor

    # elif(status == 0 or status == 2):
    #     for i in range(0, len(PosicoesY)):
    #         if(PosicoesY[i] > ValorTesoura and PosicoesY[i] > maior):
    #             maior = PosicoesY[i]
    #     return maior
    for i in range(0, len(PosicoesY)):
        if(PosicoesY[i] > ValorTesoura and PosicoesY[i] > maior):
            maior = PosicoesY[i]
        return maior

if(valorTesoura in posicoes_y):
    posicoes_y.remove(valorTesoura)

for i in range(0, len(posicoes_y)):
    if(posicoes_y[i] == valorTesoura):
        posicoes_y.remove(valorTesoura)
    elif((posicoes_y[i] == valorTesoura + 1) or (posicoes_y[i] == valorTesoura + 2) or (posicoes_y[i] == valorTesoura + 3)):
        posicoes_y.remove(posicoes_y[i])
    elif((posicoes_y[i] == valorTesoura - 1) or (posicoes_y[i] == valorTesoura - 2) or (posicoes_y[i] == valorTesoura - 3)):
        posicoes_y.remove(posicoes_y[i])

print(posicoes_y)

linhas = situacao(valorTesoura, posicoes_y)

print("LINHAS atrasadas: ", linhas[0])
print("LINHAS adiantadas: ", linhas[1])

status = -1

if(linhas[0] >= 2 or (linhas[0] >= 1 and linhas[1] <= 1)):
    print("\nstatus: atrasada")
    status = 0

elif(linhas[1] > 1 and linhas[1] >= linhas[0]):
    print("\nstatus: adiantada")
    status = 1

else:
    print("\nstatus: corta")
    status = 2

mais_proxima = pega_linha_mais_proxima(valorTesoura, posicoes_y, status)

if(status == 0):
    diff = valorTesoura - mais_proxima

    print("Linha atrasada mais proxima a tesoura: ", mais_proxima)
    print("Atraso em unidades: ", diff)

elif(status == 1):
    diff = mais_proxima - valorTesoura

    print("Linha Adiantada mais proxima a tesoura: ", mais_proxima)
    print("Avanço em unidades: ", diff)

elif(status == 2):
    diff = valorTesoura - mais_proxima

    print("Linha mais proxima a tesoura: ", mais_proxima)
    print("Dentro do limite, diferença de: ", diff)


#%% Show results online
cv2.namedWindow('canny', cv2.WINDOW_KEEPRATIO)
while True:
    
    cv2.imshow('canny', canny)

    if 0xFF & cv2.waitKey(1) == ord('q'):
        break
    
cv2.destroyAllWindows()

#%% Save results
cv2.imwrite('results/menos/out.png', out)
cv2.imwrite('results/menos/tmp.png', canny)
cv2.imwrite('results/menos/opening.png', opening)

# %%
